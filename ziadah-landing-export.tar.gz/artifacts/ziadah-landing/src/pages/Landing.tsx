import { useEffect, useMemo, useRef, useState } from "react";
import type { LucideIcon } from "lucide-react";
import {
  Bike, Store, Shirt, Smartphone, Sparkles,
  UtensilsCrossed, Dumbbell, Gem, Home, Package,
  Stethoscope, Award,
} from "lucide-react";
import PageShell from "../components/PageShell";
import { Logo } from "../components/Nav";
import HeroUseCaseCarousel from "../components/HeroUseCaseCarousel";
import PlatformModal from "../components/PlatformModal";
import HomeCalculator from "../components/HomeCalculator";
import SEO from "../components/SEO";
import { getPageKeywords } from "@/seo/page-keywords";
import { OrganizationSchema, SoftwareAppSchema, WebSiteSchema, HowToSchema, FAQSchema } from "../components/JsonLd";
import WidgetsShowcaseSection from "../components/WidgetsShowcaseSection";
import { useLanguage } from "@/i18n/LanguageContext";
import { t as staticT } from "@/i18n/translations";
import { useSiteT } from "@/cms/siteContent";
import { AI_TOPUPS, parsePrice, fmtPrice } from "@/data/aiTopups";
import { scrollToHashElement } from "@/utils/anchorScroll";
import { navigateTo } from "@/components/PageTransition";
import { sectors } from "@/data/sectors";
import { useLangAwareLocation } from "@/hooks/useLangAwareLocation";
import { useMarqueeShiftSync } from "@/hooks/useMarqueeShiftSync";
import { useMeetingBooking } from "@/components/MeetingBookingProvider";

const SECTOR_LUCIDE_ICONS: Record<string, LucideIcon> = {
  "delivery-apps":       Bike,
  "ecommerce-platforms": Store,
  "abayas-fashion":      Shirt,
  "electronics":         Smartphone,
  "beauty-care":         Sparkles,
  "restaurants-cafes":   UtensilsCrossed,
  "health-fitness":      Dumbbell,
  "jewelry":             Gem,
  "home-supplies":       Home,
  "digital-products":    Package,
  "clinics":             Stethoscope,
  "gold":                Award,
};

/** عيّنة مختصرة للصفحة الرئيسية — التوصيل والمنصات أولاً ثم أشهر المجالات */
const SECTOR_TEASER_SLUGS = [
  "delivery-apps",
  "ecommerce-platforms",
  "abayas-fashion",
  "electronics",
  "beauty-care",
  "restaurants-cafes",
  "health-fitness",
  "jewelry",
  "home-supplies",
  "digital-products",
  "clinics",
  "gold",
] as const;

const storeLogos = [
  { name: "BestClean", src: "/logos/bestclean.png" },
  { name: "Reeq Alnahl", src: "/logos/reeq-alnahl.png" },
  { name: "Altamimi", src: "/logos/altamimi.png" },
  { name: "ZUM", src: "/logos/zum.png" },
  { name: "CB", src: "/logos/cb.png" },
  { name: "12 CUPS", src: "/logos/12cups.png" },
  { name: "RIBAL", src: "/logos/ribal.png" },
  { name: "SHFT", src: "/logos/shft.png" },
  { name: "FOR HER", src: "/logos/for-her.png" },
  { name: "Abaq Alghim", src: "/logos/abaq-alghim.png" },
  { name: "FABIAN", src: "/logos/fabian.png" },
  { name: "Natural Touch", src: "/logos/natural-touch.png" },
  { name: "image_223", src: "/logos/image-223.png" },
  { name: "Mazeed", src: "/logos/mazeed.png" },
  { name: "AlSalman Oud", src: "/logos/alsalman-oud.png" },
  { name: "PC Palace", src: "/logos/pc-palace.png" },
];

function GlassCard({
  children,
  className = "",
  style = {},
  lift = false,
}: {
  children: React.ReactNode;
  className?: string;
  style?: React.CSSProperties;
  lift?: boolean;
}) {
  const ref = useRef<HTMLDivElement>(null);
  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const onMove = (e: MouseEvent) => {
      const r = el.getBoundingClientRect();
      el.style.setProperty(
        "--gx",
        ((e.clientX - r.left) / r.width) * 100 + "%",
      );
      el.style.setProperty(
        "--gy",
        ((e.clientY - r.top) / r.height) * 100 + "%",
      );
    };
    el.addEventListener("mousemove", onMove);
    return () => el.removeEventListener("mousemove", onMove);
  }, []);
  return (
    <div
      ref={ref}
      className={`gc${lift ? " gc-lift" : ""} ${className}`}
      style={style}
    >
      <div className="shine" />
      {children}
    </div>
  );
}

function SecTag({ children }: { children: React.ReactNode }) {
  return (
    <div className="stag rv">
      <span className="stag-dot" />
      {children}
    </div>
  );
}

// ── Live Demo Store Section ────────────────────────────────────

const DEMO_STORE = "https://ky0vcg.zid.store";

const LIVE_TABS_AR = [
  { id: "home",    label: "🏠 الرئيسية",        url: DEMO_STORE + "/",        desc: "اكتشف اقتراحات المنتجات الذكية على الصفحة الرئيسية" },
  { id: "product", label: "🛍️ صفحة المنتج",    url: DEMO_STORE + "/products", desc: "شاهد التوصيات الذكية أثناء تصفح المنتج" },
  { id: "cart",    label: "🛒 صفحة السلة",      url: DEMO_STORE + "/cart",     desc: "جرّب عروض زيادة قبل إتمام الشراء" },
];

const LIVE_TABS_EN = [
  { id: "home",    label: "🏠 Home",         url: DEMO_STORE + "/",        desc: "Discover AI product suggestions on the homepage" },
  { id: "product", label: "🛍️ Product Page", url: DEMO_STORE + "/products", desc: "See smart recommendations while browsing a product" },
  { id: "cart",    label: "🛒 Cart Page",    url: DEMO_STORE + "/cart",     desc: "Try Ziadah offers before completing checkout" },
];

function LiveDemoSection({ lang }: { lang: string }) {
  const isAr = lang === "ar";
  const tabs = isAr ? LIVE_TABS_AR : LIVE_TABS_EN;
  const [activeIdx, setActiveIdx] = useState(0);
  const activeTab = tabs[activeIdx];

  return (
    <section id="live-demo" className="live-demo-sec">
      <div className="wrap">
        {/* Header */}
        <div className="tc" style={{ marginBottom: 40 }}>
          <div className="stag" style={{ margin: "0 auto 18px" }}>
            <span className="stag-dot" />
            {isAr ? "المتجر التجريبي" : "Live Demo Store"}
          </div>
          <h2 className="st rv d1 font-semibold">
            {isAr ? "جرّب زيادة الآن في متجر حقيقي" : "Try Ziadah live in a real store"}
          </h2>
          <p className="ssub rv d2" style={{ maxWidth: 560, margin: "0 auto" }}>
            {isAr
              ? "تصفّح المتجر التجريبي وشاهد كيف تعمل ميزات زيادة على أرض الواقع — دون الحاجة لإنشاء حساب"
              : "Browse our demo store and see how Ziadah features work in the real world — no account needed"}
          </p>
        </div>

        {/* Tab switcher */}
        <div className="ld-tabs rv d2" role="tablist" aria-label={isAr ? "صفحات المتجر التجريبي" : "Demo store pages"}>
          {tabs.map((tab, i) => (
            <button
              key={tab.id}
              role="tab"
              aria-selected={activeIdx === i}
              className={`ld-tab${activeIdx === i ? " ld-tab--on" : ""}`}
              onClick={() => setActiveIdx(i)}
            >
              {tab.label}
            </button>
          ))}
        </div>

        {/* Page description */}
        <p className="ld-tab-desc rv d2">{activeTab.desc}</p>

        {/* Browser frame */}
        <div className="ld-browser rv d3" role="region" aria-label={isAr ? "المتجر التجريبي" : "Demo store"}>
          {/* Chrome toolbar */}
          <div className="ld-toolbar" dir="ltr">
            <div className="ld-dots" aria-hidden>
              <span className="ld-dot ld-dot--red" />
              <span className="ld-dot ld-dot--yellow" />
              <span className="ld-dot ld-dot--green" />
            </div>
            <div className="ld-urlbar" aria-label={isAr ? "عنوان المتجر التجريبي" : "Demo store address"}>
              <svg width="14" height="14" viewBox="0 0 14 14" fill="none" aria-hidden style={{ opacity: .5, flexShrink: 0 }}>
                <path d="M7 1.5a5.5 5.5 0 1 0 0 11 5.5 5.5 0 0 0 0-11ZM1 7h12M7 1.5C5.7 3 5 4.9 5 7s.7 4 2 5.5M7 1.5C8.3 3 9 4.9 9 7s-.7 4-2 5.5" stroke="currentColor" strokeWidth="1.2" strokeLinecap="round"/>
              </svg>
              <span className="ld-url-text">{activeTab.url.replace("https://", "")}</span>
            </div>
            <a
              href={activeTab.url}
              target="_blank"
              rel="noopener noreferrer"
              className="ld-open-btn"
              aria-label={isAr ? "فتح في تبويب جديد" : "Open in new tab"}
              title={isAr ? "فتح في تبويب جديد" : "Open in new tab"}
            >
              <svg width="14" height="14" viewBox="0 0 14 14" fill="none" aria-hidden>
                <path d="M6 2H2a1 1 0 0 0-1 1v9a1 1 0 0 0 1 1h9a1 1 0 0 0 1-1V8M9 1h4m0 0v4m0-4L6 8" stroke="currentColor" strokeWidth="1.4" strokeLinecap="round" strokeLinejoin="round"/>
              </svg>
            </a>
          </div>

          {/* iframe */}
          <div className="ld-frame-wrap">
            <iframe
              key={activeTab.url}
              src={activeTab.url}
              className="ld-frame"
              title={isAr ? "المتجر التجريبي — زيادة" : "Demo Store — Ziadah"}
              allow="accelerometer; clipboard-write; encrypted-media; gyroscope"
              loading="lazy"
            />
            {/* Fallback overlay if iframe is blocked */}
            <div className="ld-fallback" aria-hidden>
              <div className="ld-fallback-inner">
                <svg width="40" height="40" viewBox="0 0 40 40" fill="none">
                  <rect width="40" height="40" rx="12" fill="rgba(124,58,237,.15)"/>
                  <path d="M14 20h12M22 15l5 5-5 5" stroke="#a855f7" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                </svg>
                <p style={{ margin: "12px 0 4px", fontWeight: 700 }}>
                  {isAr ? "فتح المتجر التجريبي" : "Open Demo Store"}
                </p>
                <a href={activeTab.url} target="_blank" rel="noopener noreferrer" className="ld-fallback-btn">
                  {isAr ? "اضغط هنا للمتابعة" : "Click here to continue"}
                </a>
              </div>
            </div>
          </div>
        </div>

        {/* CTA below frame */}
        <div className="ld-cta rv d4">
          <a href={DEMO_STORE} target="_blank" rel="noopener noreferrer" className="ld-cta-link">
            {isAr ? "فتح المتجر التجريبي كاملاً" : "Open full demo store"}
            <svg width="16" height="16" viewBox="0 0 16 16" fill="none" aria-hidden>
              <path d="M3 8h10M9 4l4 4-4 4" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round" strokeLinejoin="round"/>
            </svg>
          </a>
        </div>
      </div>
    </section>
  );
}

// ── Demo Flow Section ─────────────────────────────────────────

const DEMO_PHASES_AR = [
  "بيانات العملاء تتدفق للـ Agent",
  "AI Agent بيحلل السلوك والتفضيلات",
  "توصيات مخصصة لكل عميل",
];
const DEMO_PHASES_EN = [
  "Customer data flowing to Agent",
  "AI Agent analyzing behavior",
  "Personalized recommendations ready",
];

function DemoPhaseIndicator({ lang }: { lang: string }) {
  const [phase, setPhase] = useState(0);
  useEffect(() => {
    const id = setInterval(() => setPhase((p) => (p + 1) % 3), 2600);
    return () => clearInterval(id);
  }, []);
  const phases = lang === "ar" ? DEMO_PHASES_AR : DEMO_PHASES_EN;
  return (
    <div className="demo-phase-bar">
      {phases.map((label, i) => (
        <div key={i} className={`demo-phase-item${phase === i ? " demo-phase-active" : ""}`}>
          <span className="demo-phase-dot" />
          <span className="demo-phase-text">{label}</span>
        </div>
      ))}
    </div>
  );
}

function DemoFlowSection({ lang, tr }: { lang: string; tr: Record<string, string> }) {
  const isAr = lang === "ar";
  const nasserSigs = [
    { c: "#a855f7", t: tr.demoMaleSig1 },
    { c: "#06b6d4", t: tr.demoMaleSig2 },
    { c: "#10b981", t: tr.demoMaleSig3 },
  ];
  const nouraSigs = [
    { c: "#ec4899", t: tr.demoFemaleSig1 },
    { c: "#a855f7", t: tr.demoFemaleSig2 },
    { c: "#f59e0b", t: tr.demoFemaleSig3 },
  ];
  return (
    <div className="dfs">
      <DemoPhaseIndicator lang={lang} />

      <div className="dfs-card gc">
        <div className="shine" />

        {/* ROW 1: profile | hflow | engine | hflow | profile */}
        <div className="dfs-top">

          {/* NASSER */}
          <div className="dfs-profile rv d1">
            <div className="dfs-av-wrap">
              <div className="dfs-av-ring" />
              <div className="dfs-av-ring dfs-av-ring-2" />
              <img src="/avatar-male.webp" className="dfs-av" alt="" loading="lazy" />
              <div className="dfs-av-badge dfs-av-badge-p">{tr.demoMaleChip}</div>
            </div>
            <div className="dfs-pbody">
              <div className="dfs-pname">{tr.demoMaleName}</div>
              <div className="dfs-pmeta">{tr.demoMaleMeta}</div>
              <div className="dfs-sigs">
                {nasserSigs.map((s, i) => (
                  <div key={i} className="dfs-sig">
                    <i style={{ background: s.c, boxShadow: `0 0 5px ${s.c}` }} />
                    {s.t}
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Horizontal flow: Nasser → engine */}
          <div className="dfs-hflow" aria-hidden="true">
            <div className="dfs-hline dfs-hline-p" />
            {[0,1,2,3].map(i => (
              <span key={i} className="dfs-hpt dfs-hpt-p" style={{ "--di": i } as React.CSSProperties} />
            ))}
          </div>

          {/* AI ENGINE hub */}
          <div className="dfs-engine">
            <div className="dfs-engine-ring" />
            <div className="dfs-engine-ring dfs-engine-ring-2" />
            <svg width="38" height="38" viewBox="0 0 32 32" fill="none" aria-hidden="true">
              <circle cx="16" cy="16" r="14" fill="rgba(124,58,237,.22)" stroke="rgba(168,85,247,.6)" strokeWidth="1.5" />
              <path d="M16 7 L11 21 L16 17 L21 21 Z" fill="rgba(168,85,247,.95)" />
              <circle cx="16" cy="16" r="2.5" fill="#c084fc" />
            </svg>
            <div className="dfs-engine-lbl">{isAr ? "محرك الذكاء الاصطناعي" : "AI Engine"}</div>
            <div className="dfs-engine-sub">{isAr ? "يحلل · يفهم · يخصص" : "Analyze · Personalize"}</div>
            <div className="dfs-edots" aria-hidden="true">
              {[0,1,2].map(i => <span key={i} className="dfs-edot" style={{ "--di": i } as React.CSSProperties} />)}
            </div>
          </div>

          {/* Horizontal flow: engine ← Noura */}
          <div className="dfs-hflow" aria-hidden="true">
            <div className="dfs-hline dfs-hline-pk" />
            {[0,1,2,3].map(i => (
              <span key={i} className="dfs-hpt dfs-hpt-pk" style={{ "--di": i } as React.CSSProperties} />
            ))}
          </div>

          {/* NOURA */}
          <div className="dfs-profile rv d2">
            <div className="dfs-av-wrap">
              <div className="dfs-av-ring dfs-av-ring-pk" />
              <div className="dfs-av-ring dfs-av-ring-2 dfs-av-ring-pk" />
              <img src="/avatar-female.webp" className="dfs-av" alt="" loading="lazy" />
              <div className="dfs-av-badge dfs-av-badge-pk">{tr.demoFemaleChip}</div>
            </div>
            <div className="dfs-pbody">
              <div className="dfs-pname">{tr.demoFemaleName}</div>
              <div className="dfs-pmeta">{tr.demoFemaleMeta}</div>
              <div className="dfs-sigs">
                {nouraSigs.map((s, i) => (
                  <div key={i} className="dfs-sig">
                    <i style={{ background: s.c, boxShadow: `0 0 5px ${s.c}` }} />
                    {s.t}
                  </div>
                ))}
              </div>
            </div>
          </div>

        </div>{/* /dfs-top */}

        {/* ROW 2: upward connector — store data rises into engine */}
        <div className="dfs-store-up" aria-hidden="true">
          <div className="dfs-sup-line" />
          {[0,1,2,3].map(i => (
            <span key={i} className="dfs-upt" style={{ "--di": i } as React.CSSProperties} />
          ))}
        </div>

        {/* ROW 2b: Store data label */}
        <div className="dfs-store-label">
          <div className="dfs-store-line" />
          <span className="dfs-store-tag">{isAr ? "بيانات المتجر" : "Store Data"}</span>
          <div className="dfs-store-line" />
        </div>
        <div className="dfs-store rv d2">

          {/* Product Catalog */}
          <div className="dfs-store-card gc">
            <div className="shine" />
            <div className="dfs-sc-hd">
              <div className="dfs-sc-ico" style={{ background: "rgba(245,158,11,.1)", border: "1px solid rgba(245,158,11,.22)" }}>🛍️</div>
              <div>
                <div className="dfs-sc-title">{isAr ? "كتالوج المنتجات" : "Product Catalog"}</div>
                <div className="dfs-sc-sub">{isAr ? "4 منتجات · متزامنة" : "4 products · synced"}</div>
              </div>
              <div className="dfs-live-dot" style={{ color: "#f59e0b" }}>● {isAr ? "مباشر" : "Live"}</div>
            </div>
            <div className="dfs-sc-list">
              {([
                { icon: "👟", name: isAr ? "حذاء Ultra Pro" : "Ultra Pro Sneakers", cat: isAr ? "رياضة" : "Sports", price: isAr ? "349 ⃁" : "SAR 349", stock: 23 },
                { icon: "🎧", name: isAr ? "سماعات JBL Reflect" : "JBL Reflect Earbuds", cat: isAr ? "إلكترونيات" : "Electronics", price: isAr ? "219 ⃁" : "SAR 219", stock: 41 },
                { icon: "🥤", name: isAr ? "بروتين Whey" : "Whey Protein Drink", cat: isAr ? "لياقة" : "Fitness", price: isAr ? "149 ⃁" : "SAR 149", stock: 88 },
                { icon: "🧴", name: isAr ? "كريم مرطب Nivea" : "Nivea Moisturizer", cat: isAr ? "تجميل" : "Beauty", price: isAr ? "89 ⃁" : "SAR 89", stock: 112 },
              ] as { icon: string; name: string; cat: string; price: string; stock: number }[]).map((p, i) => (
                <div key={i} className="dfs-sc-row">
                  <span className="dfs-sc-emoji">{p.icon}</span>
                  <div className="dfs-sc-info">
                    <div className="dfs-sc-name">{p.name}</div>
                    <div className="dfs-sc-cat">{p.cat}</div>
                  </div>
                  <div className="dfs-sc-price">{p.price}</div>
                  <div className="dfs-sc-stock">{p.stock} {isAr ? "قطعة" : "in stock"}</div>
                </div>
              ))}
            </div>
          </div>

          {/* Order History */}
          <div className="dfs-store-card gc">
            <div className="shine" />
            <div className="dfs-sc-hd">
              <div className="dfs-sc-ico" style={{ background: "rgba(6,182,212,.1)", border: "1px solid rgba(6,182,212,.22)" }}>📦</div>
              <div>
                <div className="dfs-sc-title">{isAr ? "سجل الطلبات" : "Order History"}</div>
                <div className="dfs-sc-sub">{isAr ? "آخر 4 طلبات" : "Last 4 orders"}</div>
              </div>
              <div className="dfs-live-dot" style={{ color: "#06b6d4" }}>● {isAr ? "مباشر" : "Live"}</div>
            </div>
            <div className="dfs-sc-list">
              {([
                { av: "👨", customer: isAr ? "ناصر" : "Nasser", items: isAr ? "حذاء Ultra Pro" : "Ultra Pro Sneakers", status: "done" as const, total: isAr ? "349 ⃁" : "SAR 349" },
                { av: "👩", customer: isAr ? "نوره" : "Noura", items: isAr ? "عطر + كريم Nivea" : "Perfume + Nivea Cream", status: "done" as const, total: isAr ? "538 ⃁" : "SAR 538" },
                { av: "👨", customer: isAr ? "ناصر" : "Nasser", items: isAr ? "سماعات JBL + بروتين" : "JBL Earbuds + Protein", status: "active" as const, total: isAr ? "368 ⃁" : "SAR 368" },
                { av: "👩", customer: isAr ? "نوره" : "Noura", items: isAr ? "باليت مكياج" : "Makeup Palette", status: "done" as const, total: isAr ? "289 ⃁" : "SAR 289" },
              ] as { av: string; customer: string; items: string; status: "done"|"active"; total: string }[]).map((o, i) => (
                <div key={i} className="dfs-sc-row">
                  <span className="dfs-sc-emoji">{o.av}</span>
                  <div className="dfs-sc-info">
                    <div className="dfs-sc-name">{o.customer}</div>
                    <div className="dfs-sc-cat">{o.items}</div>
                  </div>
                  <div className={`dfs-sc-status ${o.status === "active" ? "dfs-sc-status-act" : ""}`}>
                    {o.status === "done" ? (isAr ? "مكتمل" : "Done") : (isAr ? "جاري" : "Active")}
                  </div>
                  <div className="dfs-sc-price">{o.total}</div>
                </div>
              ))}
            </div>
          </div>

        </div>{/* /dfs-store */}

        {/* ROW 3: output divider — engine → personalized recs */}
        <div className="dfs-divider" aria-hidden="true">
          <div className="dfs-div-line" />
          <div className="dfs-div-label">{isAr ? "↓ توصيات مخصصة" : "↓ Personalized output"}</div>
          <div className="dfs-div-line" />
          <div className="dfs-vpt-wrap dfs-vpt-wrap-l">
            {[0,1,2].map(i => <span key={i} className="dfs-vpt dfs-vpt-g" style={{ "--di": i } as React.CSSProperties} />)}
          </div>
          <div className="dfs-vpt-wrap dfs-vpt-wrap-r">
            {[0,1,2].map(i => <span key={i} className="dfs-vpt dfs-vpt-g" style={{ "--di": i } as React.CSSProperties} />)}
          </div>
        </div>

        {/* ROW 3: recommendations */}
        <div className="dfs-recs">

          {/* Nasser recs */}
          <div className="dfs-rec dfs-rec-p rv d3">
            <div className="dfs-rec-hd">
              <div>
                <div className="dfs-pname">{tr.demoMaleName}</div>
                <div className="dfs-pmeta">{tr.demoMaleMeta}</div>
              </div>
              <div className="demo-chip">{tr.demoMaleChip}</div>
            </div>
            <div className="demo-sl">{tr.aiSuggestions}</div>
            <div className="demo-suggs">
              <div className="demo-sugg">
                <div className="demo-si" style={{ background: "rgba(240,240,248,.06)", border: "1px solid rgba(240,240,248,.12)" }}>
                  <svg width="18" height="18" viewBox="0 0 18 18" fill="none"><ellipse cx="9" cy="12" rx="5.5" ry="3.5" fill="rgba(240,240,248,.12)" stroke="rgba(240,240,248,.4)" strokeWidth="1" /><path d="M3.5 12 Q5.5 5.5 9 3.5 Q12.5 5.5 14.5 12" fill="rgba(15,10,30,.4)" stroke="rgba(240,240,248,.18)" strokeWidth="1" /></svg>
                </div>
                <div className="demo-sb"><div className="demo-sn">{tr.demoMaleSugg1Name}</div><div className="demo-sw">{tr.demoMaleSugg1Sub}</div></div>
                <div className="demo-sp">{tr.demoMaleSugg1Price}</div>
              </div>
              <div className="demo-sugg">
                <div className="demo-si" style={{ background: "rgba(168,85,247,.07)", border: "1px solid rgba(168,85,247,.15)" }}>
                  <svg width="18" height="18" viewBox="0 0 18 18" fill="none"><rect x="3" y="7" width="12" height="6" rx="2" fill="rgba(168,85,247,.15)" stroke="rgba(168,85,247,.5)" strokeWidth="1" /><circle cx="6.5" cy="10" r="1.2" fill="rgba(168,85,247,.5)" /><circle cx="11.5" cy="10" r="1.2" fill="rgba(168,85,247,.5)" /></svg>
                </div>
                <div className="demo-sb"><div className="demo-sn">{tr.demoMaleSugg2Name}</div><div className="demo-sw">{tr.demoMaleSugg2Sub}</div></div>
                <div className="demo-sp">{tr.demoMaleSugg2Price}</div>
              </div>
            </div>
          </div>

          {/* Noura recs */}
          <div className="dfs-rec dfs-rec-pk rv d4">
            <div className="dfs-rec-hd">
              <div>
                <div className="dfs-pname">{tr.demoFemaleName}</div>
                <div className="dfs-pmeta">{tr.demoFemaleMeta}</div>
              </div>
              <div className="demo-chip" style={{ background: "rgba(236,72,153,.12)", border: "1px solid rgba(236,72,153,.28)", color: "#f9a8d4" }}>{tr.demoFemaleChip}</div>
            </div>
            <div className="demo-sl">{tr.aiSuggestions}</div>
            <div className="demo-suggs">
              <div className="demo-sugg">
                <div className="demo-si" style={{ background: "rgba(236,72,153,.07)", border: "1px solid rgba(236,72,153,.15)" }}>
                  <svg width="18" height="18" viewBox="0 0 18 18" fill="none"><rect x="2" y="5" width="14" height="9" rx="2" fill="rgba(236,72,153,.12)" stroke="rgba(236,72,153,.45)" strokeWidth="1" /><rect x="4" y="7" width="3" height="2" rx=".6" fill="rgba(255,130,160,.3)" /><rect x="8" y="7" width="3" height="2" rx=".6" fill="rgba(200,70,120,.3)" /></svg>
                </div>
                <div className="demo-sb"><div className="demo-sn">{tr.demoFemaleSugg1Name}</div><div className="demo-sw">{tr.demoFemaleSugg1Sub}</div></div>
                <div className="demo-sp">289 ⃁</div>
              </div>
              <div className="demo-sugg">
                <div className="demo-si" style={{ background: "rgba(168,85,247,.07)", border: "1px solid rgba(168,85,247,.15)" }}>
                  <svg width="18" height="18" viewBox="0 0 18 18" fill="none"><rect x="5" y="3" width="8" height="11" rx="2" fill="rgba(168,85,247,.12)" stroke="rgba(168,85,247,.4)" strokeWidth="1" /><ellipse cx="9" cy="14.5" rx="3" ry="1.5" fill="rgba(168,85,247,.08)" stroke="rgba(168,85,247,.3)" strokeWidth="1" /></svg>
                </div>
                <div className="demo-sb"><div className="demo-sn">{tr.demoFemaleSugg2Name}</div><div className="demo-sw">{tr.demoFemaleSugg2Sub}</div></div>
                <div className="demo-sp">449 ⃁</div>
              </div>
            </div>
          </div>

        </div>{/* /dfs-recs */}

      </div>{/* /dfs-card */}
    </div>
  );
}

export default function Landing() {
  const { lang, dir } = useLanguage();
  const t = useSiteT();
  const tr = t[lang];
  const [, goRoute] = useLangAwareLocation();
  const [pricingMode, setPricingMode] = useState<"m" | "y">("y");
  const [landingTopupOpen, setLandingTopupOpen] = useState<number | null>(null);
  const [landingTopupSel, setLandingTopupSel] = useState<Record<number, number | null>>({});
  const toggleLandingTopup = (i: number) => setLandingTopupOpen((prev) => (prev === i ? null : i));
  const selectLandingTopup = (i: number, idx: number | null) => {
    setLandingTopupSel((prev) => ({ ...prev, [i]: idx }));
    setLandingTopupOpen(null);
  };
  const [openFaq, setOpenFaq] = useState<number | null>(null);
  const [platformModalOpen, setPlatformModalOpen] = useState(false);
  const { openMeetingBooking } = useMeetingBooking();

  const logosMarqueeTrackRef = useRef<HTMLDivElement>(null);
  const testimonialsMarquee1Ref = useRef<HTMLDivElement>(null);
  const testimonialsMarquee2Ref = useRef<HTMLDivElement>(null);
  useMarqueeShiftSync(logosMarqueeTrackRef);
  useMarqueeShiftSync(testimonialsMarquee1Ref);
  useMarqueeShiftSync(testimonialsMarquee2Ref);

  useEffect(() => {
    const obs = new IntersectionObserver(
      (es) => {
        es.forEach((e) => {
          if (e.isIntersecting) e.target.classList.add("on");
        });
      },
      { threshold: 0.07, rootMargin: "0px 0px -24px 0px" },
    );
    document.querySelectorAll(".rv").forEach((el) => obs.observe(el));
    return () => obs.disconnect();
  }, []);

  /** فتح رابط فيه #pricing أو #faq (مشاركة) — تمرير للقسم مع تعويض شريط التنقل الثابت */
  useEffect(() => {
    const scrollIfHash = () => {
      const id = window.location.hash.replace(/^#/, "").split("?")[0];
      if (!id || (id !== "pricing" && id !== "faq")) return;
      const reduced = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
      const behavior: ScrollBehavior = reduced ? "auto" : "smooth";
      const run = () => {
        scrollToHashElement(id, behavior);
      };
      window.requestAnimationFrame(() => {
        window.requestAnimationFrame(run);
      });
    };

    const t = window.setTimeout(scrollIfHash, 200);
    window.addEventListener("hashchange", scrollIfHash);
    return () => {
      clearTimeout(t);
      window.removeEventListener("hashchange", scrollIfHash);
    };
  }, []);

  // Custom cursor — فقط على الديسكتوب (لا يوجد ماوس على الجوال)
  useEffect(() => {
    if (window.matchMedia("(pointer: coarse)").matches) return; // جوال/لمس → تخطي
    const cur = document.getElementById("zd-cur");
    const curR = document.getElementById("zd-curR");
    if (!cur || !curR) return;
    let mx = 0,
      my = 0,
      rx = 0,
      ry = 0;
    let rafId: number;
    const onMove = (e: MouseEvent) => {
      mx = e.clientX;
      my = e.clientY;
      cur.style.left = mx - 5 + "px";
      cur.style.top = my - 5 + "px";
    };
    function loop() {
      rx += (mx - rx - 18) * 0.11;
      ry += (my - ry - 18) * 0.11;
      curR!.style.left = rx + "px";
      curR!.style.top = ry + "px";
      rafId = requestAnimationFrame(loop);
    }
    document.addEventListener("mousemove", onMove);
    rafId = requestAnimationFrame(loop);
    return () => {
      document.removeEventListener("mousemove", onMove);
      cancelAnimationFrame(rafId);
    };
  }, []);

  useEffect(() => {
    const handleVisibility = () => {
      document.body.classList.toggle("page-hidden", document.hidden);
    };
    handleVisibility();
    document.addEventListener("visibilitychange", handleVisibility);
    return () => {
      document.removeEventListener("visibilitychange", handleVisibility);
      document.body.classList.remove("page-hidden");
    };
  }, []);

  const prices = {
    m:         { s: 29,    g: 290,    p: 790,    b: "1,990"  },
    y:         { s: 24,    g: 249,    p: 666,    b: "1,333"  },
    yAnnual:   { s: 290,   g: "2,990",p: "7,990",b: "15,990" },
    yOrig:     { s: "348", g: "3,480",p: "9,480",b: "23,880" },
    yDisc:     { s: "17%", g: "14%",  p: "16%",  b: "33%"   },
  } as const;

  const pm = pricingMode;
  const ld = tr.landing;

  const pricingAiSpark = (
    <svg
      className="p-ai-spark-svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      aria-hidden={true}
    >
      <path
        d="M12 1.5l1.35 4.85L18.5 8.5l-4.85 1.35L12 15l-1.65-5.15L5.5 8.5l5.15-1.15L12 1.5z"
        fill="currentColor"
        opacity="0.92"
      />
      <circle cx="19.5" cy="5.5" r="1.15" fill="currentColor" opacity="0.45" />
      <circle cx="4.5" cy="17" r="0.85" fill="currentColor" opacity="0.38" />
    </svg>
  );

  const row1Avatars = ["R", "T", "S", "F", "N", "B"];
  const row1Colors = [
    "linear-gradient(135deg,#7c3aed,#5b21b6)",
    "linear-gradient(135deg,#059669,#047857)",
    "linear-gradient(135deg,#ec4899,#be185d)",
    "linear-gradient(135deg,#7c3aed,#4f46e5)",
    "linear-gradient(135deg,#10b981,#059669)",
    "linear-gradient(135deg,#06b6d4,#0891b2)",
  ];
  const row2Avatars = ["A", "R", "K", "Q", "K", "Y"];
  const row2Colors = [
    "linear-gradient(135deg,#a855f7,#7c3aed)",
    "linear-gradient(135deg,#ec4899,#9333ea)",
    "linear-gradient(135deg,#06b6d4,#0891b2)",
    "linear-gradient(135deg,#4f46e5,#4338ca)",
    "linear-gradient(135deg,#f59e0b,#d97706)",
    "linear-gradient(135deg,#f59e0b,#92400e)",
  ];
  const trRow1 = tr.landing.testimonialsRow1 as { text: string; name: string; role: string }[];
  const trRow2 = tr.landing.testimonialsRow2 as { text: string; name: string; role: string }[];
  const testimonialsRow1 = trRow1.map((t, i) => ({
    ...t,
    av: row1Avatars[i % row1Avatars.length],
    col: row1Colors[i % row1Colors.length],
  }));
  const testimonialsRow2 = trRow2.map((t, i) => ({
    ...t,
    av: row2Avatars[i % row2Avatars.length],
    col: row2Colors[i % row2Colors.length],
  }));
  const faqs = tr.landing.faqList as { q: string; a: string }[];
  const pk = getPageKeywords("/");

  const landingStars = useMemo(
    () =>
      Array.from({ length: 160 }, (_, i) => ({
        id: i,
        left: Math.random() * 100,
        top: Math.random() * 100,
        size: 0.5 + Math.random() * 2,
        opacity: 0.1 + Math.random() * 0.7,
      })),
    [],
  );

  return (
    <>
      <SEO
        titleAr={t.ar.landing.seoTitle}
        titleEn={t.en.landing.seoTitle}
        descriptionAr={t.ar.landing.seoDesc}
        descriptionEn={t.en.landing.seoDesc}
        canonical="/"
        keywordsAr={pk?.keywordsAr}
        keywordsEn={pk?.keywordsEn}
      />
      <OrganizationSchema />
      <SoftwareAppSchema />
      <WebSiteSchema />
      <HowToSchema />
      <FAQSchema faqs={faqs} />
      <PageShell>
        {/* CURSOR — ديسكتوب فقط */}
        <div id="zd-cur" className="desktop-only" style={{ width: 10, height: 10, background: "var(--p3)", borderRadius: "50%", position: "fixed", pointerEvents: "none", zIndex: 9999, mixBlendMode: "screen", transition: "width .18s,height .18s,background .18s", top: -999, left: -999 }} />
        <div id="zd-curR" className="desktop-only" style={{ width: 36, height: 36, border: "1px solid rgba(168,85,247,.4)", borderRadius: "50%", position: "fixed", pointerEvents: "none", zIndex: 9998, transition: "all .3s", top: -999, left: -999 }} />
        {/* NAV */}
        
        {/* HERO */}
        <section className="hero hero-v2" dir={dir} style={{ alignItems: "center", justifyContent: "center" }}>
          <div className="hero-grid">
            <div className="hero-copy-col">
              <div className="hero-in hero-copy-inner">
                <div className="hero-mobile-logo">
                  <Logo />
                </div>
                <div className="hbadge">
                  <span className="hbadge-pill">{tr.landing.aiBadge}</span>
                  <span className="hbadge-txt">
                    {tr.landing.aiBadgeText}
                  </span>
                </div>
                <h1 className="ht pt-[6px] pb-[6px] mt-[0px] mb-[20px] font-semibold">
                  <span className="ht-line1 font-thin">
                    {tr.landing.heroTitle1}
                  </span>
                  {tr.landing.heroTitleEm && <em>{tr.landing.heroTitleEm}</em>}
                  <span className="grad font-extrabold hero-title-grad">
                    {tr.landing.heroTitleGrad}
                  </span>
                </h1>
                <p className="hero-sub" dangerouslySetInnerHTML={{ __html: tr.landing.heroSub }} />
                <div className="hero-ctas">
                  <button
                    onClick={() => setPlatformModalOpen(true)}
                    className="btn-p btn-p-hero"
                    style={{ cursor: "pointer", border: "none", fontFamily: "inherit" }}
                  >
                    {tr.landing.ctaPrimary}
                  </button>
                  <a href="#hiw" className="btn-g btn-g-hero">
                    {tr.landing.ctaSecondary}
                  </a>
                </div>
              </div>
            </div>
            <div className="hero-carousel-col">
              <HeroUseCaseCarousel />
            </div>
          </div>
        </section>
        {/* LOGOS */}
        <div className="logos-sec">
          <div className="landing-sbar-after-hero">
            <div className="sbar sbar-hero">
              <div className="sbi">
                <div className="sbi-n">{tr.landing.stat1Value}</div>
                <div className="sbi-l text-[14px]">{tr.landing.stat1Label}</div>
              </div>
              <div className="sbi">
                <div className="sbi-n">{tr.landing.stat2Value}</div>
                <div className="sbi-l">{tr.landing.stat2Label}</div>
              </div>
              <div className="sbi">
                <div className="sbi-n">{tr.landing.stat3Value}</div>
                <div className="sbi-l">{tr.landing.stat3Label}</div>
              </div>
              <div className="sbi">
                <div className="sbi-n">{tr.landing.stat4Value}</div>
                <div className="sbi-l">{tr.landing.stat4Label}</div>
              </div>
            </div>
          </div>
          <div className="logos-mask marquee-row">
            <div
              ref={logosMarqueeTrackRef}
              className="marquee-track marquee-rtl"
              style={{ animationDuration: `${storeLogos.length * 1.75}s` }}
            >
              {[0, 1, 2].map((seg) => (
                <div key={seg} className="marquee-segment">
                  {storeLogos.map((l, i) => (
                    <div key={`${seg}-${i}`} className="lc">
                      <img
                        src={l.src}
                        alt={
                          lang === "ar"
                            ? `شعار ${l.name} — متجر يستخدم تطبيق زيادة للذكاء الاصطناعي`
                            : `${l.name} logo — Ziadah AI ecommerce merchant`
                        }
                        loading="lazy"
                        className="logo-img"
                      />
                    </div>
                  ))}
                </div>
              ))}
            </div>
          </div>
        </div>
        {/* BEFORE / AFTER + CALCULATOR */}
        <section id="why">
          <div className="wrap" style={{ display: "flex", flexDirection: "column", gap: 40, justifyContent: "flex-start", alignItems: "center" }}>
            <div className="tc" style={{ marginBottom: 0 }}>
              <SecTag>{tr.landing.whyTag}</SecTag>
              <h2 className="st rv d1 font-semibold">
                {tr.landing.whyTitle}
              </h2>
              <p className="ssub rv d2">{tr.landing.whySub}</p>
            </div>
            <div className="ba-grid" style={{ width: "100%" }}>
              <GlassCard className="ba-card rv d1">
                <div className="ba-lbl ba-lbl-b text-[18px]">{tr.landing.beforeLabel}</div>
                <div className="ba-list">
                  {(tr.landing.beforeList as string[]).map((item) => (
                    <div key={item} className="ba-row ba-row-b">
                      {item}
                    </div>
                  ))}
                </div>
                <div className="ba-foot ba-foot-b">{tr.landing.beforeFoot}</div>
              </GlassCard>
              <div className="ba-arrow-wrap rv d2">
                <div className="ba-arrow-circle">
                  <svg width="22" height="22" viewBox="0 0 22 22" fill="none">
                    <path
                      d="M4 11H18M12 5L18 11L12 17"
                      stroke="#a855f7"
                      strokeWidth="2"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                    />
                  </svg>
                </div>
              </div>
              <GlassCard
                className="ba-card rv d3"
                style={{
                  background: "rgba(88,28,220,.07)",
                  borderColor: "rgba(124,58,237,.2)",
                }}
              >
                <div className="ba-lbl ba-lbl-a text-[16px]">{tr.landing.afterLabel}</div>
                <div className="ba-list">
                  {(tr.landing.afterList as string[]).map((item) => (
                    <div key={item} className="ba-row ba-row-a">
                      {item}
                    </div>
                  ))}
                </div>
                <div className="ba-foot ba-foot-a">
                  {tr.landing.afterFoot} <span style={{ fontSize: 24 }}>{tr.landing.afterFootValue}</span>
                </div>
              </GlassCard>
            </div>
            <HomeCalculator />
          </div>
        </section>
        {/* HOW IT WORKS */}
        <section id="hiw">
          <div className="wrap">
            <div className="tc" style={{ marginBottom: 56 }}>
              <SecTag>{tr.landing.hiwTag}</SecTag>
              <h2 className="st rv d1 font-semibold">
                {tr.landing.hiwTitle}
              </h2>
              <p className="ssub rv d2">
                {tr.landing.hiwSubtitle}
              </p>
            </div>
            <div className="hiw-grid">
              {[
                {
                  step: tr.landing.step1Label,
                  title: tr.landing.step1Title,
                  desc: tr.landing.step1Desc,
                  chip: tr.landing.step1Chip,
                  icon: (
                    <svg width="32" height="32" viewBox="0 0 32 32" fill="none">
                      <rect
                        x="9"
                        y="6"
                        width="14"
                        height="20"
                        rx="3"
                        fill="rgba(124,58,237,.14)"
                        stroke="rgba(168,85,247,.45)"
                        strokeWidth="1.5"
                      />
                      <rect
                        x="12"
                        y="10"
                        width="8"
                        height="2"
                        rx="1"
                        fill="rgba(168,85,247,.55)"
                      />
                      <rect
                        x="12"
                        y="14"
                        width="5"
                        height="2"
                        rx="1"
                        fill="rgba(168,85,247,.35)"
                      />
                      <circle
                        cx="21"
                        cy="22"
                        r="6"
                        fill="rgba(16,185,129,.14)"
                        stroke="rgba(16,185,129,.5)"
                        strokeWidth="1.5"
                      />
                      <path
                        d="M18.5 22l1.5 1.5 3-3"
                        stroke="#10b981"
                        strokeWidth="1.5"
                        strokeLinecap="round"
                        strokeLinejoin="round"
                      />
                    </svg>
                  ),
                },
                {
                  step: tr.landing.step2Label,
                  title: tr.landing.step2Title,
                  desc: tr.landing.step2Desc,
                  chip: tr.landing.step2Chip,
                  icon: (
                    <svg width="32" height="32" viewBox="0 0 32 32" fill="none">
                      <circle
                        cx="16"
                        cy="13"
                        r="8"
                        fill="rgba(124,58,237,.12)"
                        stroke="rgba(168,85,247,.4)"
                        strokeWidth="1.5"
                      />
                      <path
                        d="M10 22 C10 17 13 15 16 15 C19 15 22 17 22 22"
                        fill="rgba(124,58,237,.08)"
                        stroke="rgba(168,85,247,.35)"
                        strokeWidth="1.5"
                        strokeLinecap="round"
                      />
                      <circle
                        cx="13"
                        cy="12"
                        r="1.5"
                        fill="rgba(168,85,247,.7)"
                      />
                      <circle cx="16" cy="12" r="1.5" fill="#a855f7" />
                      <circle
                        cx="19"
                        cy="12"
                        r="1.5"
                        fill="rgba(168,85,247,.7)"
                      />
                      <line
                        x1="8"
                        y1="5"
                        x2="11"
                        y2="8"
                        stroke="rgba(168,85,247,.3)"
                        strokeWidth="1"
                        strokeLinecap="round"
                      />
                      <line
                        x1="16"
                        y1="3"
                        x2="16"
                        y2="7"
                        stroke="rgba(168,85,247,.3)"
                        strokeWidth="1"
                        strokeLinecap="round"
                      />
                      <line
                        x1="24"
                        y1="5"
                        x2="21"
                        y2="8"
                        stroke="rgba(168,85,247,.3)"
                        strokeWidth="1"
                        strokeLinecap="round"
                      />
                    </svg>
                  ),
                },
                {
                  step: tr.landing.step3Label,
                  title: tr.landing.step3Title,
                  desc: tr.landing.step3Desc,
                  chip: tr.landing.step3Chip,
                  icon: (
                    <svg width="32" height="32" viewBox="0 0 32 32" fill="none">
                      <rect
                        x="4"
                        y="20"
                        width="5"
                        height="8"
                        rx="1.5"
                        fill="rgba(168,85,247,.25)"
                        stroke="rgba(168,85,247,.45)"
                        strokeWidth="1.2"
                      />
                      <rect
                        x="13"
                        y="14"
                        width="5"
                        height="14"
                        rx="1.5"
                        fill="rgba(168,85,247,.45)"
                        stroke="rgba(168,85,247,.6)"
                        strokeWidth="1.2"
                      />
                      <rect
                        x="22"
                        y="7"
                        width="5"
                        height="21"
                        rx="1.5"
                        fill="#a855f7"
                        stroke="rgba(168,85,247,.7)"
                        strokeWidth="1.2"
                      />
                      <path
                        d="M6.5 18 L15.5 12 L24.5 5"
                        stroke="rgba(196,132,252,.5)"
                        strokeWidth="1.5"
                        strokeLinecap="round"
                        strokeDasharray="2 3"
                      />
                      <circle
                        cx="24.5"
                        cy="5"
                        r="2.5"
                        fill="rgba(196,132,252,.4)"
                        stroke="rgba(196,132,252,.6)"
                        strokeWidth="1"
                      />
                    </svg>
                  ),
                },
              ].map((c, i) => (
                <GlassCard key={i} lift className={`rv d${i + 1}`}>
                  <div className="hiw-p">
                    <div className="step-lbl">{c.step}</div>
                    <div className="hiw-img">{c.icon}</div>
                    <div className="hiw-t">{c.title}</div>
                    <div className="hiw-d">{c.desc}</div>
                    <div className="hiw-chip">✓ {c.chip}</div>
                  </div>
                </GlassCard>
              ))}
            </div>
          </div>
        </section>
        {/* SECTORS — قطاعات عامة + عيّنة مختصرة */}
        <section id="sectors" className="landing-sectors-section">
            <div className="landing-sectors-panel rv d1">
              <div className="landing-sectors-panel__inner">
                <div className="tc landing-sectors-head">
                  <SecTag>{tr.landing.sectorsTag}</SecTag>
                  <h2 className="st rv d1 landing-sectors-title">{tr.landing.sectorsTitle}</h2>
                  <p className="ssub rv d2 landing-sectors-sub">{tr.landing.sectorsBriefSub}</p>
                </div>
                <div className="landing-sectors-grid">
                  {SECTOR_TEASER_SLUGS.map((slug) => sectors.find((s) => s.slug === slug))
                    .filter(Boolean)
                    .map((sec) => {
                      const stitle = lang === "ar" ? sec!.titleAr : sec!.titleEn;
                      return (
                        <button
                          key={sec!.slug}
                          type="button"
                          className="landing-sectors-chip"
                          dir={dir}
                          onClick={() => goRoute(`/sectors/${sec!.slug}`)}
                        >
                          <span className="landing-sectors-chip__ico" aria-hidden>
                            {(() => {
                              const Icon = SECTOR_LUCIDE_ICONS[sec!.slug];
                              return Icon ? <Icon size={18} strokeWidth={1.7} /> : sec!.icon;
                            })()}
                          </span>
                          <span className="landing-sectors-chip__label">{stitle}</span>
                        </button>
                      );
                    })}
                </div>
                <div className="tc landing-sectors-cta">
                  <button
                    type="button"
                    onClick={() => goRoute("/sectors")}
                    className="btn-p"
                    style={{ cursor: "pointer", fontFamily: "var(--font)", border: "none" }}
                  >
                    {tr.landing.sectorsCta}
                  </button>
                </div>
              </div>
            </div>
        </section>
        <WidgetsShowcaseSection />

        {/* LIVE DEMO STORE */}
        <LiveDemoSection lang={lang} />

        {/* PERSONALIZATION DEMO */}
        <section id="demo">
          <div className="wrap">
            <div className="tc" style={{ marginBottom: 40 }}>
              <SecTag>{tr.landing.personTag}</SecTag>
              <h2 className="st rv d1 font-semibold">
                {tr.landing.personTitle}
              </h2>
              <p className="ssub rv d2">
                {tr.landing.personSub}
              </p>
            </div>
            <DemoFlowSection lang={lang} tr={tr.landing as unknown as Record<string, string>} />
            
          </div>
        </section>
        {/* GOALS + PRESENTATIONS */}
        <section id="gp">
          <div className="wrap">
            <div className="tc" style={{ marginBottom: 56 }}>
              <SecTag>{tr.landing.goalsTag}</SecTag>
              <h2 className="st rv d1 font-semibold">
                {tr.landing.goalsTitle}
              </h2>
              <p className="ssub rv d2">{tr.landing.goalsSub}</p>
            </div>
            <div className="gp-grid">
              <GlassCard className="rv d1">
                <div className="gp-card">
                  <div className="gp-hd">
                    <div className="gp-ico gp-ico-p">
                      <svg width="26" height="26" viewBox="0 0 26 26" fill="none">
                        <circle
                          cx="13"
                          cy="13"
                          r="9"
                          stroke="rgba(168,85,247,.45)"
                          strokeWidth="1.5"
                        />
                        <circle
                          cx="13"
                          cy="13"
                          r="5"
                          stroke="rgba(168,85,247,.65)"
                          strokeWidth="1.5"
                        />
                        <circle cx="13" cy="13" r="2" fill="#a855f7" />
                        <line
                          x1="13"
                          y1="2"
                          x2="13"
                          y2="6"
                          stroke="rgba(168,85,247,.4)"
                          strokeWidth="1.5"
                          strokeLinecap="round"
                        />
                        <line
                          x1="13"
                          y1="20"
                          x2="13"
                          y2="24"
                          stroke="rgba(168,85,247,.4)"
                          strokeWidth="1.5"
                          strokeLinecap="round"
                        />
                        <line
                          x1="2"
                          y1="13"
                          x2="6"
                          y2="13"
                          stroke="rgba(168,85,247,.4)"
                          strokeWidth="1.5"
                          strokeLinecap="round"
                        />
                        <line
                          x1="20"
                          y1="13"
                          x2="24"
                          y2="13"
                          stroke="rgba(168,85,247,.4)"
                          strokeWidth="1.5"
                          strokeLinecap="round"
                        />
                      </svg>
                    </div>
                    <div>
                      <div className="gp-title">{tr.landing.goalsTitle1}</div>
                      <div className="gp-sub">{tr.landing.goalsSub1}</div>
                    </div>
                  </div>
                  <div className="gp-items">
                    {(tr.landing.goalsList as [string,string][]).map(([t, s]) => (
                      <div key={t} className="gp-row">
                        <div className="gdot gdot-p" />
                        <div>
                          <div className="gp-row-t">{t}</div>
                          <div className="gp-row-s">{s}</div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </GlassCard>
              <GlassCard className="rv d2">
                <div className="gp-card">
                  <div className="gp-hd">
                    <div className="gp-ico gp-ico-c">
                      <svg width="26" height="26" viewBox="0 0 26 26" fill="none">
                        <rect
                          x="3"
                          y="5"
                          width="20"
                          height="16"
                          rx="3"
                          fill="rgba(6,182,212,.1)"
                          stroke="rgba(6,182,212,.4)"
                          strokeWidth="1.5"
                        />
                        <rect
                          x="6"
                          y="9"
                          width="6"
                          height="8"
                          rx="1.5"
                          fill="rgba(6,182,212,.2)"
                          stroke="rgba(6,182,212,.35)"
                          strokeWidth="1"
                        />
                        <rect
                          x="14"
                          y="9"
                          width="6"
                          height="3.5"
                          rx="1.5"
                          fill="rgba(6,182,212,.15)"
                          stroke="rgba(6,182,212,.3)"
                          strokeWidth="1"
                        />
                        <rect
                          x="14"
                          y="14.5"
                          width="6"
                          height="2.5"
                          rx="1"
                          fill="rgba(6,182,212,.2)"
                        />
                      </svg>
                    </div>
                    <div>
                      <div className="gp-title">{tr.landing.goalsTitle2}</div>
                      <div className="gp-sub">{tr.landing.goalsSub2}</div>
                    </div>
                  </div>
                  <div className="gp-items">
                    {(tr.landing.displayList as [string,string][]).map(([t, s]) => (
                      <div key={t} className="gp-row">
                        <div className="gdot gdot-c" />
                        <div>
                          <div className="gp-row-t">{t}</div>
                          <div className="gp-row-s">{s}</div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </GlassCard>
              <GlassCard
                className="gp-banner rv"
              >
                <div className="gp-banner-ico">
                  <svg width="30" height="30" viewBox="0 0 30 30" fill="none">
                    <rect
                      x="5"
                      y="5"
                      width="20"
                      height="20"
                      rx="5"
                      fill="rgba(124,58,237,.15)"
                      stroke="rgba(168,85,247,.45)"
                      strokeWidth="1.5"
                    />
                    <circle
                      cx="10.5"
                      cy="10.5"
                      r="2"
                      fill="rgba(168,85,247,.6)"
                    />
                    <circle
                      cx="19.5"
                      cy="10.5"
                      r="2"
                      fill="rgba(168,85,247,.6)"
                    />
                    <path
                      d="M10 18 Q15 22 20 18"
                      stroke="#a855f7"
                      strokeWidth="1.8"
                      strokeLinecap="round"
                      fill="none"
                    />
                    <line
                      x1="15"
                      y1="1"
                      x2="15"
                      y2="5"
                      stroke="rgba(168,85,247,.4)"
                      strokeWidth="1.5"
                      strokeLinecap="round"
                    />
                    <line
                      x1="15"
                      y1="25"
                      x2="15"
                      y2="29"
                      stroke="rgba(168,85,247,.4)"
                      strokeWidth="1.5"
                      strokeLinecap="round"
                    />
                    <line
                      x1="1"
                      y1="15"
                      x2="5"
                      y2="15"
                      stroke="rgba(168,85,247,.4)"
                      strokeWidth="1.5"
                      strokeLinecap="round"
                    />
                    <line
                      x1="25"
                      y1="15"
                      x2="29"
                      y2="15"
                      stroke="rgba(168,85,247,.4)"
                      strokeWidth="1.5"
                      strokeLinecap="round"
                    />
                  </svg>
                </div>
                <div>
                  <div className="gp-banner-t">
                    {tr.landing.autoBannerTitle}
                  </div>
                  <div className="gp-banner-d">
                    {tr.landing.autoBannerDesc}
                  </div>
                </div>
              </GlassCard>
              <GlassCard
                className="gp-banner rv d2"
              >
                <div className="gp-banner-ico">
                  <svg width="30" height="30" viewBox="0 0 30 30" fill="none">
                    <rect
                      x="5"
                      y="5"
                      width="20"
                      height="20"
                      rx="5"
                      fill="rgba(6,182,212,.1)"
                      stroke="rgba(6,182,212,.4)"
                      strokeWidth="1.5"
                    />
                    <line x1="10" y1="11" x2="20" y2="11" stroke="rgba(6,182,212,.4)" strokeWidth="1.4" strokeLinecap="round" />
                    <line x1="10" y1="15" x2="20" y2="15" stroke="rgba(6,182,212,.7)" strokeWidth="1.8" strokeLinecap="round" />
                    <line x1="10" y1="19" x2="16" y2="19" stroke="rgba(6,182,212,.4)" strokeWidth="1.4" strokeLinecap="round" />
                    <circle cx="22" cy="19" r="3" fill="rgba(6,182,212,.15)" stroke="rgba(6,182,212,.6)" strokeWidth="1.3" />
                    <line x1="22" y1="17.5" x2="22" y2="19" stroke="rgba(6,182,212,.8)" strokeWidth="1.2" strokeLinecap="round" />
                    <circle cx="22" cy="19.8" r=".5" fill="rgba(6,182,212,.9)" />
                  </svg>
                </div>
                <div>
                  <div className="gp-banner-t">
                    {tr.landing.manualBannerTitle}
                  </div>
                  <div className="gp-banner-d">
                    {tr.landing.manualBannerDesc}
                  </div>
                </div>
              </GlassCard>
            </div>
          </div>
        </section>
        {/* DETAILED REPORTS */}
        <section id="reports">
          <div className="wrap">
            <div className="tc" style={{ marginBottom: 56 }}>
              <SecTag>{tr.landing.reportsTag}</SecTag>
              <h2 className="st rv d1 font-semibold">
                {tr.landing.reportsTitle}
              </h2>
              <p className="ssub rv d2">
                {tr.landing.reportsSub}
              </p>
            </div>

            <div className="reports-grid">
              {/* Campaign-level report card */}
              <GlassCard className="rv d1" style={{ padding: "var(--card-pad-lg)", minHeight: "100%" }}>
                <div style={{ display: "flex", alignItems: "center", gap: 12, marginBottom: 24 }}>
                  <div style={{ width: 44, height: 44, borderRadius: 14, background: "rgba(124,58,237,.12)", border: "1px solid rgba(124,58,237,.25)", display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0 }}>
                    <svg width="22" height="22" viewBox="0 0 22 22" fill="none">
                      <rect x="3" y="3" width="16" height="16" rx="3" fill="rgba(124,58,237,.12)" stroke="rgba(168,85,247,.45)" strokeWidth="1.4"/>
                      <line x1="7" y1="8" x2="15" y2="8" stroke="rgba(168,85,247,.4)" strokeWidth="1.3" strokeLinecap="round"/>
                      <line x1="7" y1="11" x2="15" y2="11" stroke="rgba(168,85,247,.7)" strokeWidth="1.6" strokeLinecap="round"/>
                      <line x1="7" y1="14" x2="11" y2="14" stroke="rgba(168,85,247,.4)" strokeWidth="1.3" strokeLinecap="round"/>
                    </svg>
                  </div>
                  <div>
                    <div style={{ fontSize: 16, fontWeight: 800 }}>{tr.landing.reportsCampaignTitle}</div>
                    <div style={{ fontSize: 12, color: "var(--td)", marginTop: 2 }}>{tr.landing.reportsCampaignSub}</div>
                  </div>
                </div>

                {/* Campaign name bar */}
                <div style={{ padding: "10px 14px", background: "rgba(124,58,237,.06)", border: "1px solid rgba(124,58,237,.15)", borderRadius: 10, marginBottom: 16, display: "flex", alignItems: "center", justifyContent: "space-between" }}>
                  <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
                    <div style={{ width: 6, height: 6, borderRadius: "50%", background: "#a855f7", boxShadow: "0 0 6px #a855f7" }}/>
                    <span style={{ fontSize: 13, fontWeight: 700 }}>{tr.landing.reportsCampaignName}</span>
                  </div>
                  <span style={{ fontSize: 11, color: "var(--p4)", fontWeight: 700, background: "rgba(168,85,247,.1)", border: "1px solid rgba(168,85,247,.2)", padding: "2px 10px", borderRadius: 50 }}>{tr.landing.reportsCampaignActive}</span>
                </div>

                {/* Stats grid */}
                <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10 }}>
                  {(tr.landing.reportsCampaignStats as { label: string; value: string; sub?: string; icon: string }[]).map((s, i) => {
                    const colors = ["#06b6d4", "#a855f7", "#10b981", "#f59e0b"];
                    return (
                    <div key={i} style={{ padding: "14px 14px", background: "var(--s2)", border: "1px solid var(--b1)", borderRadius: 12 }}>
                      <div style={{ fontSize: 18, marginBottom: 6 }}>{s.icon}</div>
                      <div style={{ fontSize: 18, fontWeight: 900, color: colors[i], lineHeight: 1 }}>{s.value}</div>
                      {s.sub && <div style={{ fontSize: 11, color: "var(--td)", marginTop: 2 }}>{tr.landing.reportsRate} {s.sub}</div>}
                      <div style={{ fontSize: 11, color: "var(--td)", marginTop: 4 }}>{s.label}</div>
                    </div>
                  );
                  })}
                </div>

                {/* Mini trend bar */}
                <div style={{ marginTop: 16, padding: "12px 14px", background: "rgba(16,185,129,.05)", border: "1px solid rgba(16,185,129,.15)", borderRadius: 10, display: "flex", alignItems: "center", gap: 10 }}>
                  <svg width="56" height="24" viewBox="0 0 56 24" fill="none">
                    <polyline points="2,20 10,16 18,14 26,10 34,8 42,5 54,2" stroke="#10b981" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" fill="none"/>
                    <polygon points="2,20 10,16 18,14 26,10 34,8 42,5 54,2 54,24 2,24" fill="rgba(16,185,129,.08)"/>
                  </svg>
                  <div style={{ fontSize: 12, color: "#10b981", fontWeight: 700 }}>{tr.landing.reportsGrowth}</div>
                </div>
              </GlassCard>

              {/* Product-level report card */}
              <GlassCard className="rv d2" style={{ padding: "var(--card-pad-lg)", minHeight: "100%", color: "rgba(255, 255, 255, 1)" }}>
                <div style={{ display: "flex", alignItems: "center", gap: 12, marginBottom: 24 }}>
                  <div style={{ width: 44, height: 44, borderRadius: 14, background: "rgba(6,182,212,.1)", border: "1px solid rgba(6,182,212,.22)", display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0 }}>
                    <svg width="22" height="22" viewBox="0 0 22 22" fill="none">
                      <rect x="3" y="12" width="4" height="7" rx="1.5" fill="rgba(6,182,212,.2)" stroke="rgba(6,182,212,.55)" strokeWidth="1.2"/>
                      <rect x="9" y="8" width="4" height="11" rx="1.5" fill="rgba(6,182,212,.35)" stroke="rgba(6,182,212,.65)" strokeWidth="1.2"/>
                      <rect x="15" y="4" width="4" height="15" rx="1.5" fill="rgba(6,182,212,.55)" stroke="rgba(6,182,212,.8)" strokeWidth="1.2"/>
                      <path d="M4.5 10.5 L11 7 L17 3.5" stroke="rgba(6,182,212,.4)" strokeWidth="1.3" strokeLinecap="round" strokeDasharray="2 2"/>
                    </svg>
                  </div>
                  <div>
                    <div style={{ fontSize: 16, fontWeight: 800 }}>{tr.landing.reportsProductTitle}</div>
                    <div style={{ fontSize: 12, color: "var(--td)", marginTop: 2 }}>{tr.landing.reportsProductSub}</div>
                  </div>
                </div>

                {/* Product rows */}
                <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
                  {(tr.landing.reportsProducts as { name: string; clicks: string; clickRate: string; conv: string; convRate: string; sales: string }[]).map((p, i) => {
                    const pColors = ["#a855f7", "#06b6d4", "#10b981"];
                    const pColor = pColors[i] || "#a855f7";
                    return (
                    <div key={i} style={{ padding: "12px 14px", background: "var(--s2)", border: "1px solid var(--b1)", borderRadius: 12, display: "flex", flexDirection: "column", gap: 8 }}>
                      <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between" }}>
                        <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
                          <div style={{ width: 6, height: 6, borderRadius: "50%", background: pColor, boxShadow: `0 0 6px ${pColor}`, flexShrink: 0 }}/>
                          <span style={{ fontSize: 13, fontWeight: 700 }}>{p.name}</span>
                        </div>
                        <span style={{ fontSize: 13, fontWeight: 900, color: "#10b981" }}>{p.sales}</span>
                      </div>
                      <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
                        {[
                          { l: tr.landing.reportsClicksLabel, v: p.clicks, r: p.clickRate },
                          { l: tr.landing.reportsConvLabel, v: p.conv, r: p.convRate },
                        ].map((m, j) => (
                          <div key={j} style={{ display: "flex", gap: 4, alignItems: "center" }}>
                            <span style={{ fontSize: 12, color: "var(--td)" }}>{m.l}:</span>
                            <span style={{ fontSize: 12, fontWeight: 700, color: "var(--t)" }}>{m.v}</span>
                            <span style={{ fontSize: 11, color: pColor, background: `rgba(${pColor === "#a855f7" ? "168,85,247" : pColor === "#06b6d4" ? "6,182,212" : "16,185,129"},.1)`, padding: "1px 6px", borderRadius: 50 }}>{m.r}</span>
                          </div>
                        ))}
                      </div>
                    </div>
                  );
                  })}
                </div>

                <div style={{ marginTop: 14, padding: "10px 14px", background: "rgba(124,58,237,.05)", border: "1px solid rgba(124,58,237,.12)", borderRadius: 10, fontSize: 12, color: "var(--tm)", textAlign: "center" }}>
                  {tr.landing.reportsFooter}
                </div>
              </GlassCard>
            </div>

            {/* Bottom banner */}
            <GlassCard className="reports-banner rv d3" style={{ marginTop: 16, padding: "28px 36px", display: "flex", alignItems: "center", gap: 24, background: "rgba(124,58,237,.05)", borderColor: "rgba(124,58,237,.18)" }}>
              <div style={{ width: 52, height: 52, borderRadius: 16, background: "rgba(124,58,237,.12)", border: "1px solid rgba(124,58,237,.25)", display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0 }}>
                <svg width="26" height="26" viewBox="0 0 26 26" fill="none">
                  <circle cx="13" cy="13" r="10" fill="rgba(124,58,237,.1)" stroke="rgba(168,85,247,.4)" strokeWidth="1.5"/>
                  <path d="M13 8v5l3 3" stroke="#a855f7" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"/>
                  <circle cx="13" cy="13" r="1.5" fill="#a855f7"/>
                </svg>
              </div>
              <div style={{ flex: 1 }}>
                <div style={{ fontSize: 18, fontWeight: 800, marginBottom: 6 }}>{tr.landing.reportsBannerTitle}</div>
                <div style={{ fontSize: 14, color: "var(--tm)", lineHeight: 1.7 }}>
                  {tr.landing.reportsBannerDesc}
                </div>
              </div>
              <div className="reports-banner-stats" style={{ display: "flex", gap: 20, flexShrink: 0, flexWrap: "wrap" }}>
                {(tr.landing.reportsBannerStats as { v: string; l: string }[]).map((s, i) => (
                  <div key={i} style={{ textAlign: "center" }}>
                    <div style={{ fontSize: 20, fontWeight: 900, color: "var(--p3)" }}>{s.v}</div>
                    <div style={{ fontSize: 11, color: "var(--td)", marginTop: 2 }}>{s.l}</div>
                  </div>
                ))}
              </div>
            </GlassCard>
          </div>
        </section>
        {/* TESTIMONIALS */}
        <section id="testimonials" style={{ overflowX: "clip", paddingInline: 0 }}>
          <div className="wrap">
            <div className="tc" style={{ marginBottom: 56 }}>
              <SecTag>{tr.landing.testimonialsTag}</SecTag>
              <h2 className="st rv d1 font-semibold">
                {tr.landing.testimonialsTitle}
              </h2>
              <p className="ssub rv d2">
                {tr.landing.testimonialsSub}
              </p>
            </div>
          </div>
          <div className="marquee-row" style={{ marginBottom: 20 }}>
            <div
              ref={testimonialsMarquee1Ref}
              className="marquee-track marquee-rtl"
              style={{ animationDuration: `${testimonialsRow1.length * 4}s` }}
            >
              {[0, 1, 2].map((seg) => (
                <div key={seg} className="marquee-segment">
                  {testimonialsRow1.map((t, i) => (
                    <div key={`${seg}-${i}`} className="gc tc-card-slim">
                      <div className="tc-stars">★★★★★</div>
                      <div className="tc-text">{t.text}</div>
                      <div className="tc-author">
                        <div className="tc-av" style={{ background: t.col }}>{t.av}</div>
                        <div>
                          <div className="tc-name">{t.name}</div>
                          <div className="tc-role">{t.role}</div>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              ))}
            </div>
          </div>
          <div className="marquee-row">
            <div
              ref={testimonialsMarquee2Ref}
              className="marquee-track marquee-ltr"
              style={{ animationDuration: `${testimonialsRow2.length * 4}s` }}
            >
              {[0, 1, 2].map((seg) => (
                <div key={seg} className="marquee-segment">
                  {testimonialsRow2.map((t, i) => (
                    <div key={`${seg}-${i}`} className="gc tc-card-slim">
                      <div className="tc-stars">★★★★★</div>
                      <div className="tc-text">{t.text}</div>
                      <div className="tc-author">
                        <div className="tc-av" style={{ background: t.col }}>{t.av}</div>
                        <div>
                          <div className="tc-name">{t.name}</div>
                          <div className="tc-role">{t.role}</div>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              ))}
            </div>
          </div>
        </section>
        {/* PRICING */}
        <section id="pricing" className="pricing-sec">
          <div className="wrap">
            <div className="tc pricing-sec__intro">
              <SecTag>{tr.landing.pricingTag}</SecTag>
              <h2 className="st rv d1 font-semibold">{tr.landing.pricingTitle}</h2>
              <p className="ssub rv d2">
                {tr.landing.pricingSub}
              </p>
            </div>
            <div className="pricing-sec__toggle rv d2">
              <div className="ptog">
                <button
                  className={`ptb${pricingMode === "m" ? " on" : ""}`}
                  onClick={() => setPricingMode("m")}
                >
                  {tr.landing.monthly}
                </button>
                <button
                  className={`ptb${pricingMode === "y" ? " on" : ""}`}
                  onClick={() => setPricingMode("y")}
                >
                  {tr.landing.yearly}<span className="save-pill">{tr.landing.yearlyDiscount}</span>
                </button>
              </div>
            </div>
            <div className="pg pricing-sec__grid">
              {[
                {
                  name: tr.landing.planStarter,
                  desc: tr.landing.planStarterDesc,
                  price: prices[pricingMode].s,
                  origPrice: pricingMode === "y" ? prices.yOrig.s : null,
                  discPct: pricingMode === "y" ? prices.yDisc.s : null,
                  monthlyEquiv: pricingMode === "y" ? prices.yAnnual.s : null,
                  feat: false,
                  badge: null,
                  aiCredit: ld.planStarterCredits[pm],
                  aiNote: ld.planAiFootnote,
                  features: [...(ld.planStarterFeatures as string[])],
                  cta: tr.landing.subscribeNow,
                  ctaAction: () => setPlatformModalOpen(true),
                  fill: false,
                },
                {
                  name: tr.landing.planGrowth,
                  desc: tr.landing.planGrowthDesc,
                  price: prices[pricingMode].g,
                  origPrice: pricingMode === "y" ? prices.yOrig.g : null,
                  discPct: pricingMode === "y" ? prices.yDisc.g : null,
                  monthlyEquiv: pricingMode === "y" ? prices.yAnnual.g : null,
                  feat: false,
                  badge: null,
                  aiCredit: ld.planGrowthCredits[pm],
                  aiNote: ld.planAiFootnote,
                  features: [
                    ld.planGrowthIntro,
                    ...(ld.planGrowthFeatures as string[]),
                  ],
                  cta: tr.landing.subscribeNow,
                  ctaAction: () => setPlatformModalOpen(true),
                  fill: false,
                },
                {
                  name: tr.landing.planPro,
                  desc: tr.landing.planProDesc,
                  price: prices[pricingMode].p,
                  origPrice: pricingMode === "y" ? prices.yOrig.p : null,
                  discPct: pricingMode === "y" ? prices.yDisc.p : null,
                  monthlyEquiv: pricingMode === "y" ? prices.yAnnual.p : null,
                  feat: false,
                  badge: tr.landing.planProBadge,
                  aiCredit: ld.planProCredits[pm],
                  aiNote: ld.planAiFootnote,
                  features: [ld.planProIntro, ...(ld.planProFeatures as string[])],
                  cta: tr.landing.subscribeNow,
                  ctaAction: () => setPlatformModalOpen(true),
                  fill: false,
                },
                {
                  name: tr.landing.planBusiness,
                  desc: tr.landing.planBusinessDesc,
                  price: prices[pricingMode].b,
                  origPrice: pricingMode === "y" ? prices.yOrig.b : null,
                  discPct: pricingMode === "y" ? prices.yDisc.b : null,
                  monthlyEquiv: pricingMode === "y" ? prices.yAnnual.b : null,
                  feat: true,
                  badge: ld.planBusinessBadge,
                  aiCredit: ld.planBusinessCredits[pm],
                  aiNote: ld.planAiFootnote,
                  features: [
                    ld.planBusinessIntro,
                    ...(ld.planBusinessFeatures as string[]),
                    ...(pricingMode === "y"
                      ? [tr.landing.planBusinessGuaranteeAnnual]
                      : []),
                  ],
                  cta: tr.landing.subscribeNow,
                  ctaAction: () => setPlatformModalOpen(true),
                  fill: true,
                },
              ].map((p, i) => {
                const lSelTopupIdx = landingTopupSel[i] ?? null;
                const lSelTopup = lSelTopupIdx != null ? AI_TOPUPS[lSelTopupIdx] : null;
                const lTopupBase = (pricingMode === "y" && p.monthlyEquiv != null)
                  ? parsePrice(p.monthlyEquiv as number | string)
                  : (p.price != null ? parsePrice(p.price as number | string) : null);
                const lEffectivePrice = lSelTopup != null && lTopupBase != null
                  ? fmtPrice(lTopupBase + lSelTopup.price)
                  : p.price;
                const lPriceLabel = lSelTopup && pricingMode === "y"
                  ? (lang === "ar" ? "/ سنة" : "/ yr")
                  : tr.landing.perMonth;
                const isAr = lang === "ar";
                return (
                <GlassCard
                  key={i}
                  className={`pc rv d${i + 1}${p.feat ? " feat" : ""}`}
                  style={{ zIndex: landingTopupOpen === i ? 20 : undefined }}
                >
                  {/* Badge row — always reserves space for alignment */}
                  <div className="pc-badge-row">
                    {p.badge
                      ? <div className="pc-badge">{p.badge}</div>
                      : <div className="pc-badge-ph" aria-hidden />
                    }
                  </div>

                  {/* Plan name + desc */}
                  <div className="p-name">{p.name}</div>
                  <div className="p-desc">{p.desc}</div>

                  {/* Discount row — always reserves space */}
                  <div className="p-orig-row">
                    {p.origPrice ? (
                      <>
                        <span className="p-orig-price">{p.origPrice} ⃁</span>
                        <span className="p-disc-badge">{p.discPct} خصم</span>
                      </>
                    ) : (
                      <span className="p-orig-ph" aria-hidden>‎</span>
                    )}
                  </div>

                  {/* Price */}
                  <div className="p-price">
                    {p.price != null ? (
                      <>
                        <span className="p-price-main">
                          <span className="p-num">{lEffectivePrice}</span>
                          <span className="p-cur">⃁</span>
                        </span>
                        <span className="p-per">{lPriceLabel}</span>
                      </>
                    ) : (
                      <span style={{ fontSize: 26, fontWeight: 900, lineHeight: 1 }}>
                        {tr.landing.custom}
                      </span>
                    )}
                  </div>
                  {lSelTopup && lTopupBase != null && (
                    <div className="pp-price-breakdown">
                      <span>
                        {isAr ? (pricingMode === "y" ? "الخطة السنوية" : "الخطة") : (pricingMode === "y" ? "Annual plan" : "Plan")}
                        : {pricingMode === "y" ? p.monthlyEquiv : p.price} ⃁
                      </span>
                      <span className="pp-price-breakdown-sep">+</span>
                      <span>{isAr ? "نقاط" : "Points"}: {fmtPrice(lSelTopup.price)} ⃁</span>
                    </div>
                  )}

                  {/* Annual billing line — hide when topup selected in yearly mode */}
                  <div className="p-monthly-equiv">
                    {!lSelTopup && p.monthlyEquiv
                      ? `${tr.landing.monthlyEquivPrefix} ${p.monthlyEquiv} ${tr.landing.monthlyEquivSuffix}`
                      : <span aria-hidden>‎</span>
                    }
                  </div>

                  <hr className="p-hr" />

                  {/* AI credit box */}
                  <div className="p-ai-box" dir={dir}>
                    <div className="p-ai-box-inner">
                      <div className="p-ai-copy">
                        {pricingAiSpark}
                        <div className="p-ai-credit">{p.aiCredit}</div>
                        <div className="p-ai-note">{p.aiNote}</div>
                      </div>
                    </div>
                  </div>

                  {/* AI Topup Dropdown */}
                  <div className="ai-topup">
                    <button
                      className={`ai-topup-trigger${landingTopupOpen === i ? " open" : ""}${lSelTopup ? " has-sel" : ""}${p.feat ? " feat" : ""}`}
                      onClick={() => toggleLandingTopup(i)}
                    >
                      <span className="ai-topup-icon" aria-hidden>
                        <svg width="11" height="14" viewBox="0 0 11 14" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M6.5 1L1 8h4.5L4.5 13 10 6H5.5L6.5 1Z" fill="currentColor"/></svg>
                      </span>
                      <span className="ai-topup-label">
                        {lSelTopup
                          ? `${lSelTopup.points.toLocaleString()} ${isAr ? "نقطة إضافية" : "extra pts"}`
                          : isAr ? "نقاط إضافية اختيارية" : "Optional extra points"}
                      </span>
                      {lSelTopup && (
                        <span className="ai-topup-sel-price">+{fmtPrice(lSelTopup.price)} ⃁</span>
                      )}
                      <svg className="ai-topup-chevron" width="14" height="14" viewBox="0 0 14 14" fill="none" aria-hidden>
                        <path d="M3 5l4 4 4-4" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"/>
                      </svg>
                    </button>
                    {landingTopupOpen === i && (
                      <div className="ai-topup-list">
                        <button
                          className={`ai-topup-opt${lSelTopupIdx == null ? " active" : ""}`}
                          onClick={() => selectLandingTopup(i, null)}
                        >
                          <span>{isAr ? "بدون نقاط إضافية" : "No extra points"}</span>
                          <span>—</span>
                        </button>
                        {AI_TOPUPS.map((pkg, ti) => (
                          <button
                            key={ti}
                            className={`ai-topup-opt${lSelTopupIdx === ti ? " active" : ""}`}
                            onClick={() => selectLandingTopup(i, ti)}
                          >
                            <span>{pkg.points.toLocaleString()} {isAr ? "نقطة" : "pts"}</span>
                            <span>+{fmtPrice(pkg.price)} ⃁</span>
                          </button>
                        ))}
                      </div>
                    )}
                  </div>

                  {/* Feature list */}
                  <ul className="p-list">
                    {p.features.map((l, j) => (
                      <li key={`pf-${i}-${j}`}>{l}</li>
                    ))}
                  </ul>

                  {/* CTA pinned to bottom */}
                  <button
                    onClick={p.ctaAction}
                    className={`pbtn ${p.fill ? "pbtn-fill" : "pbtn-ghost"}`}
                    style={{ cursor: "pointer", border: "none", fontFamily: "inherit", width: "100%" }}
                  >
                    {p.cta}
                  </button>
                </GlassCard>
                );
              })}
            </div>

            {/* Compare link */}
            <div className="tc" style={{ marginTop: 36 }}>
              <button
                onClick={() => navigateTo("/pricing")}
                style={{
                  display: "inline-flex",
                  alignItems: "center",
                  gap: 8,
                  background: "rgba(124,58,237,.1)",
                  border: "1px solid rgba(124,58,237,.28)",
                  borderRadius: 12,
                  padding: "11px 28px",
                  color: "rgba(216,180,254,.9)",
                  fontSize: 14,
                  fontWeight: 700,
                  fontFamily: "var(--font)",
                  cursor: "pointer",
                  transition: "all .2s",
                }}
                onMouseEnter={(e) => {
                  (e.currentTarget as HTMLButtonElement).style.background = "rgba(124,58,237,.2)";
                  (e.currentTarget as HTMLButtonElement).style.borderColor = "rgba(124,58,237,.5)";
                  (e.currentTarget as HTMLButtonElement).style.color = "#fff";
                }}
                onMouseLeave={(e) => {
                  (e.currentTarget as HTMLButtonElement).style.background = "rgba(124,58,237,.1)";
                  (e.currentTarget as HTMLButtonElement).style.borderColor = "rgba(124,58,237,.28)";
                  (e.currentTarget as HTMLButtonElement).style.color = "rgba(216,180,254,.9)";
                }}
              >
                <svg width="15" height="15" viewBox="0 0 15 15" fill="none">
                  <rect x="1" y="1" width="5" height="5" rx="1" stroke="currentColor" strokeWidth="1.4"/>
                  <rect x="9" y="1" width="5" height="5" rx="1" stroke="currentColor" strokeWidth="1.4"/>
                  <rect x="1" y="9" width="5" height="5" rx="1" stroke="currentColor" strokeWidth="1.4"/>
                  <rect x="9" y="9" width="5" height="5" rx="1" stroke="currentColor" strokeWidth="1.4"/>
                </svg>
                {lang === "ar" ? "مقارنة تفصيلية بين الباقات" : "Detailed plan comparison"}
                <svg width="14" height="14" viewBox="0 0 14 14" fill="none" style={{ transform: lang === "ar" ? "rotate(180deg)" : "none" }}>
                  <path d="M3 7h8M8 4l3 3-3 3" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
                </svg>
              </button>
            </div>

          </div>
        </section>
        {/* HELP CENTER */}
        <section id="faq">
          <div className="wrap">
            <SecTag>{tr.landing.faqTag}</SecTag>
            <h2 className="st rv d1 font-semibold" style={{ marginBottom: 48 }}>
              {tr.landing.faqTitle}
            </h2>
            <div className="hc-wrap">
              <GlassCard className="hc-left rv">
                <h3>{tr.landing.faqWeAreHere}</h3>
                <p>
                  {tr.landing.faqWeAreHereDesc}
                </p>
                <div className="hc-btns">
                  <a
                    href="https://api.whatsapp.com/send/?phone=966510131856"
                    target="_blank"
                    rel="noreferrer"
                    className="hcb hcb-wa"
                  >
                    <div className="hcb-ico hcb-wa">
                      <svg width="20" height="20" viewBox="0 0 20 20" fill="none">
                        <path
                          d="M10 2C5.6 2 2 5.6 2 10C2 11.4 2.4 12.8 3 14L2 18L6 17C7.2 17.6 8.6 18 10 18C14.4 18 18 14.4 18 10C18 5.6 14.4 2 10 2ZM13.5 12.5C13.3 13 12.5 13.5 12 13.5C11.3 13.5 10.8 13.3 8.5 11.5C6.5 9.7 6 8.7 6 8C6 7.5 6.2 7 6.7 6.5C7 6.2 7.3 6 7.7 6C8 6 8.3 6.5 8.7 7.3C9 7.8 9.3 8.5 9.3 8.8C9.3 9 9 9.3 8.8 9.5C8.7 9.7 8.5 9.8 8.7 10.2C9 10.7 9.5 11.3 10 11.8C10.5 12.3 11 12.7 11.5 12.8C11.8 13 12 12.8 12.3 12.5C12.5 12.2 12.8 12 13 12C13.3 12 14 12.8 13.5 12.5Z"
                          fill="rgba(37,211,102,0.6)"
                        />
                      </svg>
                    </div>
                    <div>
                      <div>{tr.landing.faqWhatsapp}</div>
                      <div className="hcb-sub">{tr.landing.faqWhatsappSub}</div>
                    </div>
                  </a>
                  <button
                    type="button"
                    onClick={() => openMeetingBooking()}
                    className="hcb hcb-cal"
                  >
                    <div className="hcb-ico hcb-cal">
                      <svg width="20" height="20" viewBox="0 0 20 20" fill="none">
                        <rect
                          x="3"
                          y="4"
                          width="14"
                          height="13"
                          rx="2"
                          fill="rgba(6,182,212,.12)"
                          stroke="rgba(6,182,212,.4)"
                          strokeWidth="1.2"
                        />
                        <line
                          x1="3"
                          y1="8"
                          x2="17"
                          y2="8"
                          stroke="rgba(6,182,212,.35)"
                          strokeWidth="1"
                        />
                        <line
                          x1="7"
                          y1="2"
                          x2="7"
                          y2="6"
                          stroke="rgba(6,182,212,.5)"
                          strokeWidth="1.2"
                          strokeLinecap="round"
                        />
                        <line
                          x1="13"
                          y1="2"
                          x2="13"
                          y2="6"
                          stroke="rgba(6,182,212,.5)"
                          strokeWidth="1.2"
                          strokeLinecap="round"
                        />
                        <rect
                          x="6"
                          y="10"
                          width="3"
                          height="2.5"
                          rx=".5"
                          fill="rgba(6,182,212,.3)"
                        />
                        <rect
                          x="11"
                          y="10"
                          width="3"
                          height="2.5"
                          rx=".5"
                          fill="rgba(6,182,212,.3)"
                        />
                      </svg>
                    </div>
                    <div>
                      <div>{tr.landing.faqBookMeeting}</div>
                      <div className="hcb-sub">{tr.landing.faqBookMeetingSub}</div>
                    </div>
                  </button>
                  <a href="/support" className="hcb hcb-doc">
                    <div className="hcb-ico hcb-doc">
                      <svg width="20" height="20" viewBox="0 0 20 20" fill="none">
                        <path
                          d="M4 3h6v14H4z"
                          fill="rgba(168,85,247,.12)"
                          stroke="rgba(168,85,247,.35)"
                          strokeWidth="1.2"
                          strokeLinejoin="round"
                        />
                        <path
                          d="M10 3h6v14h-6z"
                          fill="rgba(168,85,247,.08)"
                          stroke="rgba(168,85,247,.3)"
                          strokeWidth="1.2"
                          strokeLinejoin="round"
                        />
                        <line
                          x1="10"
                          y1="3"
                          x2="10"
                          y2="17"
                          stroke="rgba(168,85,247,.4)"
                          strokeWidth="1"
                        />
                      </svg>
                    </div>
                    <div>
                      <div>{tr.landing.faqDocs}</div>
                      <div className="hcb-sub">{tr.landing.faqDocsSub}</div>
                    </div>
                  </a>
                </div>
              </GlassCard>
              <div className="faq-list">
                {faqs.map((f, i) => (
                  <div key={i} className={`fi rv d${(i % 2) + 1}`}>
                    <button
                      type="button"
                      onClick={() => setOpenFaq(openFaq === i ? null : i)}
                      style={{
                        background:
                          openFaq === i ? "rgba(124,58,237,.06)" : "rgba(37, 0, 107, 0.05)",
                        border: `1px solid ${openFaq === i ? "rgba(124,58,237,.3)" : "var(--b1)"}`,
                        borderRadius: openFaq === i ? "14px 14px 0 0" : "14px",
                      }}
                    >
                      {f.q}
                      <span
                        style={{
                          width: 24,
                          height: 24,
                          borderRadius: "50%",
                          background: "var(--s3)",
                          display: "flex",
                          alignItems: "center",
                          justifyContent: "center",
                          fontSize: 17,
                          fontWeight: 300,
                          flexShrink: 0,
                          transform: openFaq === i ? "rotate(45deg)" : "none",
                          transition:
                            "transform .35s cubic-bezier(.34,1.56,.64,1)",
                        }}
                      >
                        +
                      </span>
                    </button>
                    <div
                      style={{
                        maxHeight: openFaq === i ? 400 : 0,
                        overflow: "hidden",
                        background: "rgba(124,58,237,.04)",
                        border:
                          openFaq === i
                            ? "1px solid rgba(124,58,237,.15)"
                            : "none",
                        borderTop: "none",
                        borderRadius: "0 0 14px 14px",
                        fontSize: 14,
                        color: "var(--tm)",
                        lineHeight: 1.8,
                        padding: openFaq === i ? "18px 22px" : 0,
                        transition: "max-height .38s ease,padding .25s",
                      }}
                    >
                      {f.a}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </section>
        {/* FINAL CTA */}
        <section className="cta-sec">
          <div className="wrap">
            <GlassCard className="cta-box rv">
              <div className="cta-glow" />
              <h2>
                {tr.landing.ctaTitle.split('\n').map((line: string, i: number) => (
                  <span key={i}>{line}{i === 0 && <br />}</span>
                ))}
              </h2>
              <p>
                {tr.landing.ctaDesc}
              </p>
              <div className="cta-btns">
                <button
                  onClick={() => setPlatformModalOpen(true)}
                  className="cta-btn cb-zid"
                  style={{ cursor: "pointer", border: "none", fontFamily: "inherit" }}
                >
                  <svg width="18" height="18" viewBox="0 0 18 18" fill="none">
                    <path d="M9 2L3 10h6l-2 6 8-10H9l2-6z" fill="#fff" />
                  </svg>
                  {tr.landing.ctaBtn}
                </button>
              </div>
              <div className="cta-note text-[16px]">{tr.landing.ctaNote}</div>
            </GlassCard>
          </div>
        </section>
      </PageShell>
      <PlatformModal open={platformModalOpen} onClose={() => setPlatformModalOpen(false)} />
    </>
  );
}
