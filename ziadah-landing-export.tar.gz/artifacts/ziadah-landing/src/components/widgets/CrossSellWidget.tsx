import UseCaseWidgetPreview from "../UseCaseWidgetPreview";
import { useLanguage } from "@/i18n/LanguageContext";
import { useSiteT } from "@/cms/siteContent";

export default function CrossSellWidget() {
  const t = useSiteT();
  const { lang } = useLanguage();
  const tr = t[lang].widgets.crossSell;

  return (
    <UseCaseWidgetPreview title={tr.title} subtitle={tr.subtitle}>
      <div style={{ marginBottom: 10 }}>
        <div style={{ fontSize: 10, color: "var(--td)", marginBottom: 8 }}>{tr.descLabel}</div>
        <div style={{ display: "flex", flexDirection: "column", gap: 7 }}>
          {tr.products.map((s, i) => (
            <div key={i} style={{
              display: "flex",
              flexDirection: "column",
              gap: 8,
              padding: "9px 10px",
              borderRadius: 10,
              background: i === 0 ? "rgba(124,58,237,.15)" : "var(--s1)",
              border: i === 0 ? "1.5px solid rgba(168,85,247,.4)" : "1.5px solid var(--b1)",
            }}>
              <div style={{ display: "flex", alignItems: "center", gap: 9 }}>
                <div style={{
                  width: 32,
                  height: 32,
                  borderRadius: 8,
                  background: "rgba(124,58,237,.15)",
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                  fontSize: 16,
                  flexShrink: 0,
                }}>{s.emoji}</div>
                <div style={{ flex: 1, minWidth: 0 }}>
                  <div style={{ fontSize: 10, fontWeight: 600, color: "var(--t)" }}>{s.name}</div>
                  {s.badge && (
                    <div style={{ fontSize: 8, padding: "1px 6px", borderRadius: 20, background: "rgba(6,182,212,.2)", color: "#06b6d4", fontWeight: 700, display: "inline-block", marginTop: 2 }}>{s.badge}</div>
                  )}
                  <div style={{ display: "flex", gap: 4, alignItems: "center", marginTop: 2 }}>
                    <span style={{ fontSize: 11, fontWeight: 800, color: "#c084fc" }}>{tr.currency}{s.price}</span>
                    {s.origPrice && <span style={{ fontSize: 9, color: "var(--td)", textDecoration: "line-through" }}>{tr.currency}{s.origPrice}</span>}
                  </div>
                </div>
              </div>
              <button style={{
                width: "100%",
                padding: "6px 10px",
                borderRadius: 10,
                background: "rgba(124,58,237,.25)",
                color: "#c084fc",
                fontSize: 10,
                fontWeight: 800,
                border: "1px solid rgba(168,85,247,.3)",
                cursor: "pointer",
              }} className="widget-btn-sm">{tr.btnAdd}</button>
            </div>
          ))}
        </div>
      </div>
      <button style={{
        width: "100%",
        padding: "9px",
        borderRadius: 12,
        background: "rgba(124,58,237,0.12)",
        backdropFilter: "blur(12px)",
        WebkitBackdropFilter: "blur(12px)",
        color: "#c084fc",
        fontSize: 14,
        fontWeight: 800,
        border: "1px solid rgba(124,58,237,0.2)",
        cursor: "pointer",
      }} className="widget-btn">
        {tr.btnCart}
      </button>
    </UseCaseWidgetPreview>
  );
}
